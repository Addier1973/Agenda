# 📐 ESQUEMÁTICO COMPLETO - INVERSOR 24V DC → 120V AC

## 🔌 Diseño Estilo EasyEDA/KiCad

---

## 📋 ESQUEMÁTICO PRINCIPAL

```
═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════
║                                                                                                                       ║
║                         INVERSOR DE ONDA SINUSOIDAL PURA - 24V DC a 120V AC @ 60Hz                                 ║
║                                  PWM @ 20kHz | H-Bridge | Transformador de Ferrita                                  ║
║                                                                                                                       ║
═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════


    ┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
    │  FUENTE DE ALIMENTACIÓN Y PROTECCIÓN                                                                        │
    └─────────────────────────────────────────────────────────────────────────────────────────────────────────────┘

         ┌──────────┐
    ─────┤   BAT1   ├───────┐
    ─    │   24V DC │       │
    ─    │   LIPO   │       │                         ┌──────────────────────────────────────┐
    ─    └──────────┘       │                         │ V+ = +24V (Red)                      │
                             │                         │ GND = 0V (Black)                     │
                         ┌───┴───┐                     │ 5V = +5V (Arduino Logic)             │
                    ─────┤  F1   ├─────────●─────●─── └──────────────────────────────────────┘
                         │ 30A   │         │     │                    V+ (Power Rail)
                         │ Fuse  │         │     │
                         └───────┘         │     └───────────────┐
                                           │                     │
                                       ┌───┴──┐             ┌────▼────┐
                                       │ C100 │             │ LM7805  │  ───→ +5V (Arduino, Drivers)
                                       │100uF │             │ Regulator│
                                       │ 50V  │             └─────────┘
                                       └───┬──┘
                                           │
                                          GND


    ┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
    │  SECCIÓN DE CONTROL - ARDUINO NANO                                                                          │
    └─────────────────────────────────────────────────────────────────────────────────────────────────────────────┘

                                   ┌─────────────────────────────────────┐
                                   │         ARDUINO NANO (U1)           │
                                   │                                     │
                       ┌───────────┤ D9  [PWM_HIGH_A]                   │
                       │           │                                     │
                       │  ┌────────┤ D10 [PWM_HIGH_B]                   │
                       │  │        │                                     │
                       │  │  ┌─────┤ D5  [PWM_LOW_A]                    │
                       │  │  │     │                                     │
                       │  │  │  ┌──┤ D6  [PWM_LOW_B]                    │
                       │  │  │  │  │                                     │
    ┌─── A0 ───────────┼──┼──┼──┼──┤ A0  [Current Sensor Input]         │
    │                  │  │  │  │  │                                     │
    │   ┌─── A1 ───────┼──┼──┼──┼──┤ A1  [Voltage Divider Input]        │
    │   │              │  │  │  │  │                                     │
    │   │     ┌────────┼──┼──┼──┼──┤ D2  [Button Input - Interrupt]     │
    │   │     │        │  │  │  │  │                                     │
    │   │     │   ┌────┼──┼──┼──┼──┤ D13 [LED Indicator]                │
    │   │     │   │    │  │  │  │  │                                     │
    │   │     │   │    │  │  │  │  │ VIN ─── +5V                         │
    │   │     │   │    │  │  │  │  │ GND ─── GND                         │
    │   │     │   │    │  │  │  │  └─────────────────────────────────────┘
    │   │     │   │    │  │  │  │
    │   │     │   │    │  │  │  │
    │   │     │   │    │  │  │  └───────────────┐
    │   │     │   │    │  │  │                  │
    │   │     │   │    │  │  └────────────────┐ │
    │   │     │   │    │  │                   │ │
    │   │     │   │    │  └─────────────────┐ │ │
    │   │     │   │    │                    │ │ │
    │   │     │   │    └──────────────────┐ │ │ │
    │   │     │   │                       │ │ │ │
    │   │     │   │                       │ │ │ │
    │   │     │   └───── LED ─────────────┼─┼─┼─┼─────●──[R_LED]──GND
    │   │     │           D13             │ │ │ │
    │   │     │                           │ │ │ │
    │   │     └───── SW1 ──────────┬──────┼─┼─┼─┼───── GND
    │   │            Button        │      │ │ │ │
    │   │                         [R]     │ │ │ │
    │   │                          │      │ │ │ │
    │   │                         +5V     │ │ │ │
    │   │                                 │ │ │ │
    │   │                                 │ │ │ │


    ┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
    │  SENSORES DE MONITOREO                                                                                      │
    └─────────────────────────────────────────────────────────────────────────────────────────────────────────────┘

    │   │                                 │ │ │ │
    │   │   ┌──────────────────┐          │ │ │ │
    │   └───┤      R1          │          │ │ │ │
    │       │     100kΩ        ├──●───────┘ │ │ │    ← A1 (Voltage Sense)
    │       └──────────────────┘  │         │ │ │
    │                             │         │ │ │
    V+  ────────────────────┐     │         │ │ │
                            │     │         │ │ │
                       ┌────┴────┐│         │ │ │
                       │   R2    ││         │ │ │
                       │  15kΩ   ││         │ │ │
                       └────┬────┘│         │ │ │
                            │     │         │ │ │
                           GND    └─────────┘ │ │
                                              │ │
    │                                         │ │
    │                  ┌─────────────────┐    │ │
    └──────────────────┤   ACS712 (U4)   ├────┘ │    ← A0 (Current Sense)
                       │   30A Module    │      │
            V+ ────────┤ VCC      OUT    ├──────┘
                       │                 │
           GND ────────┤ GND      IP+    ├────── V+ (Power Line)
                       │          IP-    ├────── (H-Bridge)
                       └─────────────────┘


    ┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
    │  DRIVERS IR2110 - LADO A (Half-Bridge A)                                                                    │
    └─────────────────────────────────────────────────────────────────────────────────────────────────────────────┘

                                 │ │ │ │
                                 │ │ │ │
              ┌──────────────────┼─┼─┘ │
              │  ┌───────────────┼─┘   │
              │  │               │     │
              │  │               │     │
              │  │   ┌───────────────────────────────┐
              │  │   │        IR2110 (U2)            │              ┌─────── Bootstrap Circuit
              │  │   │        Driver A               │              │
              │  └───┤ HIN (Pin 10)    HO (Pin 7) ───┼──────────────┼────────────┐  Gate Q1
              │      │                               │              │            │
              └──────┤ LIN (Pin 12)    LO (Pin 1) ───┼──────────────┼────────────┼──┐ Gate Q2
                     │                               │              │            │  │
          +5V ───────┤ VDD (Pin 3)     VB (Pin 8) ───┼──────●───────┘            │  │
                     │                               │      │                    │  │
          +5V ───────┤ VCC (Pin 2)     VS (Pin 5) ───┼──────┼────●               │  │
                     │                               │      │    │               │  │
          GND ───────┤ COM (Pin 13)                  │     ┌┴┐   │               │  │
                     │                               │     │ │C1 │               │  │
                     └───────────────────────────────┘  D1 │ │10µF               │  │
                                                         ──┤ │   │               │  │
                                                           └┬┘   │               │  │
                                      Bootstrap ────────────┘    │               │  │
                                      Diode UF4007               │               │  │
                                                                 │               │  │
                                                                GND              │  │
                                                                                 │  │


    ┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
    │  H-BRIDGE COMPLETO - MOSFETs                                                                                │
    └─────────────────────────────────────────────────────────────────────────────────────────────────────────────┘

                                                                                 │  │
                                                                                 │  │
                  V+ ──────────────────────●────────────────────────────────────┼──┼────●
                                           │                                    │  │    │
                                           │                                    │  │    │
                                      ┌────▼───┐                           ┌────▼──┴┐   │
                        Q1 (High-A)   │   D    │ Q3 (High-B)               │   D    │   │
                        IRFZ44N       │  ┌─┐   │ IRFZ44N                   │  ┌─┐   │   │
                           ┌──────────┤G │▲│ S ├──────────┐      ┌─────────┤G │▲│ S ├───┼─┐
                           │          │  └─┘   │          │      │         │  └─┘   │   │ │
                           │          └────┬───┘          │      │         └────┬───┘   │ │
                           │               │              │      │              │       │ │
                           │      NODE_A ──●              │      │     NODE_B ──●       │ │
                           │          ┌────┴───┐          │      │         ┌────┴───┐   │ │
                           │          │   D    │          │      │         │   D    │   │ │
                           │  Q2      │  ┌─┐   │ Q4       │      │ Q4      │  ┌─┐   │   │ │
                           │(Low-A)   │  │▼│   │(Low-B)   │      │(Low-B)  │  │▼│   │   │ │
                           └──────────┤G └─┘ S ├──────────┼──┐   └─────────┤G └─┘ S ├───┼─┼──┐
                                      │        │          │  │              │        │   │ │  │
                                      └────────┘          │  │              └────────┘   │ │  │
                                           │              │  │                   │       │ │  │
                                          GND ────────────┼──┼──────────────────●───────┼─┼──┼─── GND
                                                          │  │                           │ │  │
                                         OUT_A ───────────●  │              OUT_B ───────┘ │  │
                                         (Node A)           │              (Node B)        │  │
                                                            │                              │  │
                                                            │                              │  │


    ┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
    │  DRIVERS IR2110 - LADO B (Half-Bridge B)                                                                    │
    └─────────────────────────────────────────────────────────────────────────────────────────────────────────────┘

                                                            │                              │  │
                                            ┌───────────────┘                              │  │
                                            │  ┌────────────────────────────────────────────┘  │
              ┌─────────────────────────────┼──┼───────────────────────────────────────────────┘
              │  ┌──────────────────────────┼──┘
              │  │                          │
              │  │   ┌───────────────────────────────┐
              │  │   │        IR2110 (U3)            │              ┌─────── Bootstrap Circuit
              │  │   │        Driver B               │              │
              │  └───┤ HIN (Pin 10)    HO (Pin 7) ───┼──────────────┼────────────┐  Gate Q3
              │      │                               │              │            │
              └──────┤ LIN (Pin 12)    LO (Pin 1) ───┼──────────────┼────────────┼──┐ Gate Q4
                     │                               │              │            │  │
          +5V ───────┤ VDD (Pin 3)     VB (Pin 8) ───┼──────●───────┘            │  │
                     │                               │      │                    │  │
          +5V ───────┤ VCC (Pin 2)     VS (Pin 5) ───┼──────┼────●               │  │
                     │                               │      │    │               │  │
          GND ───────┤ COM (Pin 13)                  │     ┌┴┐   │               │  │
                     │                               │     │ │C2 │               │  │
                     └───────────────────────────────┘  D2 │ │10µF               │  │
                                                         ──┤ │   │               │  │
                                                           └┬┘   │               │  │
                                      Bootstrap ────────────┘    │               │  │
                                      Diode UF4007               │               │  │
                                                                 │               │  │
                                                                GND              │  │
                                                                                 │  │
                                                                                 │  │


    ┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
    │  TRANSFORMADOR DE FERRITA + FILTRO LC                                                                       │
    └─────────────────────────────────────────────────────────────────────────────────────────────────────────────┘

                                         OUT_A                         OUT_B
                                           │                             │
                                           │                             │
                                           │                             │
                                       ┌───▼─────────────────────────────▼───┐
                                       │                                     │
                                       │    TRANSFORMADOR DE FERRITA (T1)    │
                                       │                                     │
                                       │    Núcleo: ETD39/ETD44 (N87)       │
                                       │    Frecuencia: 20 kHz               │
                                       │                                     │
                                       │         ┌───────────┐               │
                                       │  P1 ●───┤           │───● S1        │
                                       │         │  ╔═══╗    │               │
                                       │  (12T)  │  ║ ▓ ║    │  (80T)        │
                                       │         │  ║▓▓▓║    │               │
                                       │  P2 ●───┤  ╚═══╝    │───● S2        │
                                       │         └───────────┘               │
                                       │                                     │
                                       │    Relación: 1:6.67 (aprox 1:7)    │
                                       │    24Vpp → 170Vpp                   │
                                       │                                     │
                                       └──────────┬──────────────┬───────────┘
                                                  │ S1           │ S2
                                                  │              │
                                                  │              └─────────────────┐
                                                  │                                │
                                            ┌─────▼─────┐                          │
                                            │    L1     │                          │
                                            │   10mH    │   Filtro LC              │
                                            │    5A     │   f_cutoff ≈ 500Hz       │
                                            └─────┬─────┘                          │
                                                  │                                │
                                                  ├────────●─────[C3]──────┐       │
                                                  │        │     10µF      │       │
                                                  │        │    250VAC     │       │
                                                  │       GND             GND      │
                                                  │                                │
                                               ┌──▼──┐                          ┌──▼──┐
                                               │ OUT │  120V AC @ 60Hz         │ OUT │
                                               │  L  │  Sinusoidal Pure        │  N  │
                                               └─────┘  THD < 5%                └─────┘


    ┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
    │  CIRCUITOS DE PROTECCIÓN                                                                                    │
    └─────────────────────────────────────────────────────────────────────────────────────────────────────────────┘

         ┌───────────────────┐          ┌──────────────────┐          ┌──────────────────┐
         │  PROTECCIÓN DE    │          │  CAPACITORES DE  │          │  DIODOS DE       │
         │  ENTRADA          │          │  DESACOPLE       │          │  PROTECCIÓN      │
         ├───────────────────┤          ├──────────────────┤          ├──────────────────┤
         │ • Fusible 30A     │          │ • C100: 100µF    │          │ • Body diodes    │
         │ • Inversión polar.│          │ • C_bypass: 100nF│          │   en MOSFETs     │
         │ • Voltaje monitor │          │ • Ubicación cerca│          │ • D1, D2: UF4007 │
         └───────────────────┘          │   de cada chip   │          │   (Bootstrap)    │
                                        └──────────────────┘          └──────────────────┘

         ┌───────────────────┐          ┌──────────────────┐          ┌──────────────────┐
         │  GATE RESISTORS   │          │  SNUBBER (Opc.)  │          │  THERMAL         │
         ├───────────────────┤          ├──────────────────┤          ├──────────────────┤
         │ • Rg = 10-22Ω     │          │ • RC Snubber     │          │ • Termistor NTC  │
         │ • En serie a gate │          │   en MOSFETs     │          │ • Ventilador PWM │
         │ • Reduce oscilac. │          │ • 100nF + 10Ω    │          │ • Disipador >0.5│
         └───────────────────┘          └──────────────────┘          │   °C/W           │
                                                                       └──────────────────┘


═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════
```

---

## 📊 LISTA DE MATERIALES (BOM - Bill of Materials)

| Ref | Cantidad | Componente | Valor/Modelo | Package | Descripción |
|-----|----------|------------|--------------|---------|-------------|
| **SEMICONDUCTORES** |
| U1 | 1 | Arduino Nano | ATmega328P | Module | Microcontrolador principal |
| U2, U3 | 2 | IR2110 | IR2110S | DIP-14/SOIC-16 | Driver MOSFET Half-Bridge |
| Q1, Q3 | 2 | MOSFET N-CH | IRFZ44N | TO-220 | High-side switches (55V, 49A) |
| Q2, Q4 | 2 | MOSFET N-CH | IRFZ44N | TO-220 | Low-side switches (55V, 49A) |
| U4 | 1 | Sensor Corriente | ACS712-30A | Module | Sensor de corriente Hall |
| U5 | 1 | Regulador | LM7805 | TO-220 | Regulador de voltaje 5V |
| D1, D2 | 2 | Diodo Rápido | UF4007 | DO-41 | Bootstrap diodes (1A, 1000V) |
| **PASIVOS** |
| C1, C2 | 2 | Capacitor | 10µF/25V | Electrolítico | Bootstrap caps |
| C3 | 1 | Capacitor | 10µF/250VAC | Polipropileno | Filtro de salida |
| C100 | 1 | Capacitor | 100µF/50V | Electrolítico | Bulk capacitor |
| C101-C104 | 4 | Capacitor | 100nF | Cerámico | Desacoplo drivers |
| L1 | 1 | Inductor | 10mH/5A | Toroidal | Filtro de salida |
| R1 | 1 | Resistor | 100kΩ | 1/4W | Divisor de voltaje (alto) |
| R2 | 1 | Resistor | 15kΩ | 1/4W | Divisor de voltaje (bajo) |
| R_LED | 1 | Resistor | 330Ω | 1/4W | Limitador LED |
| Rg1-Rg4 | 4 | Resistor | 10-22Ω | 1W | Gate resistors (opcional) |
| **MAGNÉTICOS** |
| T1 | 1 | Transformador | ETD39/44 | Ferrite Core | Transformador HF 1:7 |
| **PROTECCIÓN** |
| F1 | 1 | Fusible | 30A | Automotriz | Protección entrada |
| **CONECTORES** |
| J1 | 1 | Terminal | Screw 2-pin | 5mm pitch | Entrada 24V DC |
| J2 | 1 | Terminal | Screw 2-pin | 5mm pitch | Salida 120V AC |
| SW1 | 1 | Pulsador | NO | 6x6mm | Botón de encendido |
| **MECÁNICOS** |
| HS1-HS4 | 4 | Disipador | TO-220 | >0.5°C/W | Para MOSFETs |
| FAN1 | 1 | Ventilador | 12V DC | 80x80mm | Enfriamiento (opcional) |

---

## 🔌 CONEXIONES PRINCIPALES

### Alimentación
- **BAT+** (24V) → Fusible 30A → V+ (Power Rail)
- **BAT-** (GND) → Común de referencia
- **V+** → LM7805 → +5V (Lógica)

### Arduino a Drivers
- **D9** (Arduino) → **HIN** (IR2110 A)
- **D10** (Arduino) → **HIN** (IR2110 B)
- **D5** (Arduino) → **LIN** (IR2110 A)
- **D6** (Arduino) → **LIN** (IR2110 B)

### Drivers a MOSFETs
- **HO** (IR2110 A) → **Gate Q1** (High-side A)
- **LO** (IR2110 A) → **Gate Q2** (Low-side A)
- **HO** (IR2110 B) → **Gate Q3** (High-side B)
- **LO** (IR2110 B) → **Gate Q4** (Low-side B)

### H-Bridge a Transformador
- **Node A** (Q1-S / Q2-D) → **P1** (Primario T1)
- **Node B** (Q3-S / Q4-D) → **P2** (Primario T1)

### Transformador a Filtro
- **S1** (Secundario T1) → **L1** → **OUT_L** (120V AC)
- **S2** (Secundario T1) → **OUT_N** (Neutro)
- **C3** (10µF) entre **OUT_L** y **OUT_N**

### Sensores
- **A0** (Arduino) ← **OUT** (ACS712)
- **A1** (Arduino) ← **Vout** (Divisor R1/R2)

---

## ⚙️ CONFIGURACIÓN DE COMPONENTES ESPECÍFICOS

### 🔧 IR2110 Bootstrap
```
Cada driver requiere:
  • Capacitor bootstrap: 10µF/25V
  • Diodo bootstrap: UF4007 (rápido)
  • Conexión: VCC → D → VB, C entre VB y VS
```

### 🔧 MOSFET IRFZ44N
```
Especificaciones:
  • Vds: 55V (usar con 24V OK)
  • Id: 49A continuo
  • Rds(on): 17.5mΩ @ Vgs=10V
  • Qg: 63nC (carga de gate)
  
Importante:
  • Montar en disipador con pasta térmica
  • Body diode integrado (protección)
  • Gate-Source Zener: 20V (protegido)
```

### 🔧 Transformador de Ferrita
```
Diseño:
  • Núcleo: ETD39, ETD44 o equivalente
  • Material: N87 (TDK) o N97 (EPCOS)
  • Frecuencia: 20 kHz
  • Entrehierro (gap): NO necesario (uso AC)
  
Bobinado:
  • Primario: 12 espiras (AWG 14-16, ~1.6-2mm)
  • Secundario: 80 espiras (AWG 20-22, ~0.8-1mm)
  • Aislamiento: 3 capas de Kapton entre P y S
  • Relación: 1:6.67 ≈ 1:7
  
Cálculo:
  • Vprim_rms = 24V / √2 ≈ 17V
  • Vsec_rms = 17V × 7 = 119V ≈ 120V AC
```

### 🔧 Filtro LC
```
Diseño:
  • L1: 10mH, corriente >5A, Toroidal
  • C3: 10µF, 250VAC X2 (polipropileno)
  • Frecuencia de corte: f_c = 1/(2π√LC) ≈ 503 Hz
  
Propósito:
  • Atenuar 20kHz (portadora PWM)
  • Pasar 60Hz (señal deseada)
  • Atenuación @ 20kHz: ~64 dB
```

---

## 🛠️ INSTRUCCIONES DE IMPORTACIÓN A EasyEDA

### Método 1: Importar JSON

1. Abre **EasyEDA** (https://easyeda.com/)
2. Crea un nuevo proyecto: **File → New → Project**
3. Dentro del proyecto: **File → Import → EasyEDA**
4. Selecciona el archivo: `inverter_easyeda.json`
5. Click en **Import**

### Método 2: Crear Manualmente

1. **Crear nuevo esquemático**
2. **Agregar componentes** desde la biblioteca:
   - Buscar "Arduino Nano"
   - Buscar "IR2110"
   - Buscar "IRFZ44N" o "MOSFET N-channel"
   - Buscar "Transformer"
   - etc.

3. **Conectar según el esquema** mostrado arriba

4. **Asignar valores** a componentes

5. **Ejecutar ERC** (Electrical Rule Check)

6. **Generar PCB** (si es necesario)

### Método 3: Importar desde KiCad

1. En KiCad: **File → Export → Netlist**
2. En EasyEDA: **File → Import → KiCad Netlist**
3. Ajustar posiciones de componentes

---

## ⚠️ NOTAS IMPORTANTES

### Seguridad
- ⚡ **120V AC puede ser mortal** - Usar protecciones adecuadas
- 🔥 **MOSFETs calientan** - Disipadores obligatorios
- 🛡️ **Fusible es crítico** - Protección contra cortocircuito

### Pruebas
1. Verificar todas las conexiones sin alimentación
2. Medir resistencias (no debe haber cortos)
3. Primera prueba con fuente limitada a 1A
4. Verificar señales PWM con osciloscopio
5. Verificar tiempo muerto (NO shoot-through)

### Optimizaciones
- Agregar snubber RC en MOSFETs
- PCB con planos de potencia gruesos (>2mm)
- Separar tierra de potencia y señal
- Twisted-pair para señales de gate

---

## 📐 DIMENSIONES Y LAYOUT

### PCB Recomendado
- **Tamaño**: 100mm × 150mm
- **Capas**: 2 capas mínimo (4 capas ideal)
- **Grosor cobre**: 2oz (70µm) para power
- **Clearance**: 3mm entre V+ y GND

### Distribución Sugerida
```
┌─────────────────────────────────────┐
│  [Arduino]        [Sensores]        │
│                                     │
│  [Driver A]       [Driver B]        │
│                                     │
│  [Q1-Q2]          [Q3-Q4]          │
│                                     │
│  [Transformador]  [Filtro LC]       │
│                                     │
│  [Terminales IN]  [Terminales OUT]  │
└─────────────────────────────────────┘
```

---

**VERSIÓN:** 1.0  
**FORMATO:** EasyEDA Compatible  
**LICENCIA:** Open Source Hardware  

---

*Esquemático creado para el proyecto Arduino Inverter*  
*https://github.com/Tecno-Plus/Arduino-inverter*
