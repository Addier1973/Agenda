# ⚡ ESQUEMA DE ARQUITECTURA - INVERSOR DE ONDA SINUSOIDAL PURA

## 🔌 ESPECIFICACIONES TÉCNICAS

```
╔════════════════════════════════════════════════════════════════╗
║  INVERSOR DE ALTA FRECUENCIA CON ARDUINO                       ║
║  24V DC ──────────► 120V AC @ 60Hz                            ║
║  Frecuencia PWM: 20 kHz (Transformador de Ferrita)            ║
║  Topología: Puente Completo H-Bridge con SPWM                 ║
╚════════════════════════════════════════════════════════════════╝
```

---

## 🏗️ ARQUITECTURA GENERAL DEL SISTEMA

```
                     ┌──────────────────────────────────────────┐
                     │         CAPA DE CONTROL                   │
                     │         (Arduino Nano/Uno/Mega)           │
                     └──────────────┬───────────────────────────┘
                                    │
              ┌─────────────────────┼──────────────────────────┐
              │                     │                          │
              │                     │                          │
    ┌─────────▼─────────┐  ┌───────▼─────────┐  ┌────────────▼──────────┐
    │   GENERACIÓN PWM  │  │   PROTECCIONES  │  │   MONITOREO          │
    │                   │  │                 │  │                      │
    │ • Timer1 (20kHz)  │  │ • Bajo voltaje  │  │ • Sensor voltaje     │
    │ • Timer2 (6kHz)   │  │ • Sobrevoltaje  │  │ • Sensor corriente   │
    │ • Tabla Seno      │  │ • Sobrecorriente│  │ • LED indicador      │
    │   (100 muestras)  │  │ • Tiempo muerto │  │ • Serial debug       │
    └─────────┬─────────┘  └───────┬─────────┘  └────────────┬──────────┘
              │                    │                          │
              │                    │                          │
              └────────────────────┼──────────────────────────┘
                                   │
                     ┌─────────────▼──────────────┐
                     │     SEÑALES DE CONTROL     │
                     │                            │
                     │  Pin 9  → PWM_HIGH_A       │
                     │  Pin 10 → PWM_HIGH_B       │
                     │  Pin 5  → PWM_LOW_A        │
                     │  Pin 6  → PWM_LOW_B        │
                     └─────────────┬──────────────┘
                                   │
              ┌────────────────────┼────────────────────┐
              │                    │                    │
    ┌─────────▼────────┐  ┌────────▼────────┐  ┌──────▼─────────┐
    │  Driver IR2110   │  │  Driver IR2110  │  │  Driver IR2110 │
    │  (Lado Alto A)   │  │  (Lado Alto B)  │  │  (Lado Bajo)   │
    └─────────┬────────┘  └────────┬────────┘  └──────┬─────────┘
              │                    │                   │
              └────────────────────┼───────────────────┘
                                   │
                     ┌─────────────▼──────────────┐
                     │     H-BRIDGE (4 MOSFETs)   │
                     │                            │
                     │      Q1 ──┬── Q2           │
                     │           │                │
                     │      24V DC                │
                     │           │                │
                     │      Q3 ──┴── Q4           │
                     │           │                │
                     │      SALIDA PWM            │
                     └─────────────┬──────────────┘
                                   │
                     ┌─────────────▼──────────────┐
                     │  TRANSFORMADOR DE FERRITA  │
                     │                            │
                     │  Primario: 24V @ 20kHz     │
                     │  Relación: 1:6 o 1:7       │
                     │  Secundario: ~170V pico    │
                     └─────────────┬──────────────┘
                                   │
                     ┌─────────────▼──────────────┐
                     │     FILTRO LC              │
                     │                            │
                     │  L = 10mH                  │
                     │  C = 10µF                  │
                     │  (Filtro paso-bajo 60Hz)   │
                     └─────────────┬──────────────┘
                                   │
                     ┌─────────────▼──────────────┐
                     │  SALIDA: 120V AC @ 60Hz    │
                     │  (Onda Sinusoidal Pura)    │
                     └────────────────────────────┘
```

---

## 🔄 DIAGRAMA DE FLUJO DEL SOFTWARE

```
                        ┌──────────────┐
                        │   INICIO     │
                        │   setup()    │
                        └──────┬───────┘
                               │
                ┌──────────────┼──────────────┐
                │              │              │
        ┌───────▼─────┐  ┌─────▼────┐  ┌─────▼──────┐
        │ Config PWM  │  │ Config   │  │ Config     │
        │ Timer1      │  │ Timer2   │  │ I/O Pins   │
        │ (20kHz)     │  │ (6kHz)   │  │            │
        └───────┬─────┘  └─────┬────┘  └─────┬──────┘
                │              │              │
                └──────────────┼──────────────┘
                               │
                        ┌──────▼───────┐
                        │  Apagar PWM  │
                        │  inicial     │
                        └──────┬───────┘
                               │
                        ┌──────▼───────┐
                        │  Habilitar   │
                        │ Interrupción │
                        │  (Botón)     │
                        └──────┬───────┘
                               │
                        ┌──────▼───────┐
                        │ Indicador LED│
                        │  (3 parpadeos)│
                        └──────┬───────┘
                               │
              ╔════════════════▼════════════════╗
              ║         BUCLE PRINCIPAL         ║
              ║           loop()                ║
              ╚════════════════╤════════════════╝
                               │
                    ┌──────────┼──────────┐
                    │          │          │
            ┌───────▼────┐ ┌───▼───────┐ ┌▼────────┐
            │ Monitoreo  │ │ Mostrar   │ │ delay   │
            │  Sistema   │ │Información│ │ (10ms)  │
            └───────┬────┘ └───────────┘ └─────────┘
                    │
         ┌──────────┼──────────┐
         │          │          │
    ┌────▼────┐ ┌───▼────┐ ┌──▼──────┐
    │ Leer    │ │ Leer   │ │ Verificar│
    │Voltaje  │ │Corriente│ │ Límites │
    │ (A1)    │ │ (A0)   │ │         │
    └────┬────┘ └───┬────┘ └──┬──────┘
         │          │          │
         └──────────┼──────────┘
                    │
              ¿Fuera de límites?
                    │
         ┌──────────┼──────────┐
         │ Sí                  │ No
    ┌────▼────────┐     ┌──────▼──────┐
    │ Activar     │     │ Continuar   │
    │ Protección  │     │ Normal      │
    │ sobrecarga  │     │             │
    │ = true      │     │             │
    └────┬────────┘     └─────────────┘
         │
    ┌────▼────────┐
    │ Apagar      │
    │ Inversor    │
    │ LED parpadeo│
    └─────────────┘


    ╔═══════════════════════════════════════════════════════╗
    ║     INTERRUPCIÓN TIMER2 (ISR - 6000 Hz)              ║
    ║     Genera la modulación SPWM                         ║
    ╚═══════════════════════════════════════════════════════╝
                            │
                  ¿inversorEncendido?
                            │
                ┌───────────┼───────────┐
                │ No                    │ Sí
           ┌────▼────┐            ┌─────▼──────┐
           │ OCR1A=0 │            │ Leer tabla │
           │ OCR1B=0 │            │ seno[i]    │
           │ return  │            └─────┬──────┘
           └─────────┘                  │
                              ¿Semiciclo positivo?
                                        │
                            ┌───────────┼───────────┐
                            │ Sí (0-49)           │ No (50-99)
                      ┌─────▼─────┐         ┌─────▼─────┐
                      │ OCR1A = val│         │ OCR1A = 0 │
                      │ OCR1B = 0  │         │ OCR1B = val│
                      │ LOW_B = HIGH│        │ LOW_A = HIGH│
                      │ LOW_A = LOW │        │ LOW_B = LOW │
                      └─────┬─────┘         └─────┬─────┘
                            │                     │
                            └──────────┬──────────┘
                                       │
                                ┌──────▼──────┐
                                │ indiceTabla++│
                                │ if >= 100   │
                                │ reset to 0  │
                                └─────────────┘


    ╔═══════════════════════════════════════════════════════╗
    ║   INTERRUPCIÓN EXTERNA (Botón - Pin 2)               ║
    ║   Toggle ON/OFF del inversor                         ║
    ╚═══════════════════════════════════════════════════════╝
                            │
                      ┌─────▼──────┐
                      │ Debounce   │
                      │ (200ms)    │
                      └─────┬──────┘
                            │
                   ┌────────▼────────┐
                   │ Toggle          │
                   │inversorEncendido│
                   └────────┬────────┘
                            │
                ┌───────────┼───────────┐
                │ ON                    │ OFF
        ┌───────▼────┐          ┌───────▼────┐
        │ Serial:    │          │ Serial:    │
        │"ENCENDIDO" │          │"APAGADO"   │
        └────────────┘          │ OCR1A = 0  │
                                │ OCR1B = 0  │
                                │ PWMs = LOW │
                                └────────────┘
```

---

## 🎛️ DIAGRAMA DE HARDWARE Y CONEXIONES

```
╔══════════════════════════════════════════════════════════════════════╗
║                    ARDUINO NANO/UNO/MEGA                             ║
╚══════════════════════════════════════════════════════════════════════╝
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        │                     │                     │
┌───────▼────────┐    ┌───────▼────────┐    ┌──────▼───────┐
│  ENTRADAS      │    │    SALIDAS PWM  │    │  CONTROL     │
├────────────────┤    ├─────────────────┤    ├──────────────┤
│ A0: Corriente  │    │ D9:  PWM_HIGH_A │    │ D2: Botón    │
│ A1: Voltaje    │    │ D10: PWM_HIGH_B │    │ D13: LED     │
│                │    │ D5:  PWM_LOW_A  │    │              │
│                │    │ D6:  PWM_LOW_B  │    │              │
└────────┬───────┘    └─────────┬───────┘    └──────┬───────┘
         │                      │                    │
         │                      │                    │
    ┌────▼─────┐          ┌─────▼────────────────┐  │
    │ Sensores │          │   DRIVER CIRCUIT      │  │
    │          │          │                       │  │
    │ ACS712   │          │  ┌─────────────────┐ │  │
    │(Corriente│          │  │ IR2110/IR2184   │ │  │
    │          │          │  │ Bootstrap Cap   │ │  │
    │ Divisor  │          │  │ 10µF + Diodo    │ │  │
    │ Voltaje  │          │  └────────┬────────┘ │  │
    │ R1/R2    │          │           │          │  │
    └──────────┘          └───────────┼──────────┘  │
                                      │             │
                          ┌───────────▼─────────────▼───┐
                          │    H-BRIDGE MOSFETS         │
                          │                             │
                          │    Q1 (IRFZ44N)  Q2         │
                          │      │              │       │
                          │    ──┼──────────────┼──     │
                          │      │    PRIMARY   │       │
                          │  24V DC   ┌────┐   GND     │
                          │      │    │TRAN│    │       │
                          │    ──┼────┤SFO.├────┼──     │
                          │      │    └────┘    │       │
                          │    Q3              Q4       │
                          │                             │
                          └─────────────┬───────────────┘
                                        │
                          ┌─────────────▼───────────────┐
                          │  TRANSFORMADOR DE FERRITA   │
                          │                             │
                          │  Núcleo: ETD/EE/PQ          │
                          │  Material: N87 o similar    │
                          │  Frecuencia: 20 kHz         │
                          │  Primario: 10-15 vueltas    │
                          │  Secundario: 60-90 vueltas  │
                          │  Relación: 1:6 o 1:7        │
                          │                             │
                          └─────────────┬───────────────┘
                                        │
                          ┌─────────────▼───────────────┐
                          │       FILTRO LC             │
                          │                             │
                          │    ┌───[10mH]───┐           │
                          │    │            │           │
                          │   OUT       ┌──┴──┐         │
                          │             │10µF │         │
                          │             └──┬──┘         │
                          │                GND          │
                          │                             │
                          └─────────────┬───────────────┘
                                        │
                          ┌─────────────▼───────────────┐
                          │   SALIDA AC 120V @ 60Hz     │
                          │                             │
                          │   Forma: Onda Sinusoidal    │
                          │   THD: < 5% (con filtro)    │
                          │   Potencia: según MOSFETs   │
                          │                             │
                          └─────────────────────────────┘
```

---

## 📊 DIAGRAMA DE TIMERS Y FRECUENCIAS

```
╔═══════════════════════════════════════════════════════════════════╗
║                     SISTEMA DE TIMERS                             ║
╚═══════════════════════════════════════════════════════════════════╝

┌────────────────────────────────────────────────────────────────────┐
│  TIMER1 - Generación PWM de Alta Frecuencia                       │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  Modo: Fast PWM con ICR1 como TOP                                 │
│  Frecuencia: 16 MHz / (1 * 800) = 20 kHz                         │
│  Resolución: 10 bits (0-1023) → Uso efectivo 0-799               │
│  Prescaler: 1                                                      │
│  TOP (ICR1): 799                                                   │
│                                                                    │
│  Registros:                                                        │
│    • OCR1A → Pin 9  (PWM_HIGH_A)                                  │
│    • OCR1B → Pin 10 (PWM_HIGH_B)                                  │
│                                                                    │
│  ┌─────────────────────────────────────────┐                      │
│  │     Forma de Onda PWM @ 20kHz          │                      │
│  │                                         │                      │
│  │  ┌──┐   ┌──┐   ┌──┐   ┌──┐   ┌──┐    │                      │
│  │  │  │   │  │   │  │   │  │   │  │    │                      │
│  │──┘  └───┘  └───┘  └───┘  └───┘  └────│                      │
│  │  50µs (1 ciclo de 20kHz)              │                      │
│  └─────────────────────────────────────────┘                      │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────┐
│  TIMER2 - Generación de Onda Senoidal (SPWM)                      │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  Modo: CTC (Clear Timer on Compare Match)                         │
│  Frecuencia: 60 Hz × 100 muestras = 6000 Hz                      │
│  Cálculo: 16 MHz / (64 × 42) ≈ 6000 Hz                          │
│  Prescaler: 64                                                     │
│  OCR2A: 41-42                                                      │
│                                                                    │
│  Función: Actualizar índice de tabla de seno                      │
│            cada 166.67 µs                                          │
│                                                                    │
│  ┌─────────────────────────────────────────┐                      │
│  │   Tabla de Seno (100 muestras)         │                      │
│  │                                         │                      │
│  │      ╱╲         ╱╲         ╱╲          │                      │
│  │     ╱  ╲       ╱  ╲       ╱  ╲         │                      │
│  │    ╱    ╲     ╱    ╲     ╱    ╲        │                      │
│  │   ╱      ╲   ╱      ╲   ╱      ╲       │                      │
│  │──╱        ╲─╱        ╲─╱        ╲──    │                      │
│  │                                         │                      │
│  │  16.67ms (1 ciclo de 60Hz)             │                      │
│  │  100 muestras → 166.67µs cada una      │                      │
│  └─────────────────────────────────────────┘                      │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────┐
│  RELACIÓN ENTRE TIMERS - SPWM (Sinusoidal PWM)                    │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  Timer2 actualiza el valor del seno cada 166.67µs                 │
│  Timer1 genera PWM a 20kHz con duty cycle variable                │
│                                                                    │
│  Resultado: Envolvente sinusoidal @ 60Hz                          │
│             sobre portadora de 20kHz                               │
│                                                                    │
│  ┌─────────────────────────────────────────┐                      │
│  │  Amplitud PWM modulada por seno         │                      │
│  │                                         │                      │
│  │  ████████████                           │  ← Muestra 25        │
│  │  ██████████████                         │  ← Muestra 26        │
│  │  ████████████████                       │  ← Muestra 27        │
│  │  ██████████████████                     │  ← Muestra 28        │
│  │  ████████████████████  ← Pico          │  ← Muestra 29-30     │
│  │  ██████████████████                     │  ← Muestra 31        │
│  │  ████████████████                       │  ← Muestra 32        │
│  │  ██████████████                         │  ← Muestra 33        │
│  │  ████████████                           │  ← Muestra 34        │
│  │  ██████                                 │  ← Muestra 35        │
│  │                                         │                      │
│  │  Cada bloque = múltiples ciclos 20kHz   │                      │
│  │  Envolvente = 60Hz sinusoidal           │                      │
│  └─────────────────────────────────────────┘                      │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## 🔒 SISTEMA DE PROTECCIONES

```
╔═══════════════════════════════════════════════════════════════════╗
║                    MÓDULO DE PROTECCIONES                         ║
╚═══════════════════════════════════════════════════════════════════╝

                    ┌──────────────────────┐
                    │  monitorearSistema() │
                    └──────────┬───────────┘
                               │
                    ┌──────────▼──────────┐
                    │  Leer Sensores      │
                    │  • Voltaje (A1)     │
                    │  • Corriente (A0)   │
                    └──────────┬──────────┘
                               │
               ┌───────────────┼───────────────┐
               │               │               │
        ┌──────▼──────┐ ┌──────▼──────┐ ┌─────▼──────┐
        │ BAJO        │ │ SOBRE-      │ │ SOBRE-     │
        │ VOLTAJE     │ │ VOLTAJE     │ │ CORRIENTE  │
        │             │ │             │ │            │
        │ V < 22V     │ │ V > 29V     │ │ I > 800    │
        └──────┬──────┘ └──────┬──────┘ └─────┬──────┘
               │               │               │
               └───────────────┼───────────────┘
                               │
                        ¿Límite excedido?
                               │
                    ┌──────────┼──────────┐
                    │ SÍ                  │ NO
            ┌───────▼────────┐     ┌──────▼──────┐
            │ Acción:        │     │ Continuar   │
            │                │     │ Normal      │
            │ 1. sobrecarga  │     │             │
            │    = true      │     │ LED ON/OFF  │
            │ 2. inversor    │     │ según estado│
            │    Encendido   │     │             │
            │    = false     │     └─────────────┘
            │ 3. Llamar      │
            │    apagarInv() │
            │ 4. LED parpadeo│
            └────────────────┘


┌──────────────────────────────────────────────────────────────────┐
│  PROTECCIÓN POR TIEMPO MUERTO (Dead Time)                        │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Propósito: Evitar cortocircuito (shoot-through)                │
│  Valor: 2 microsegundos (configurable)                          │
│                                                                  │
│  ┌─────────────────────────────────────┐                        │
│  │   Q1/Q2 ON       Q3/Q4 ON           │                        │
│  │    ┌─────┐    ┌─────┐    ┌─────┐   │                        │
│  │ Q1 │     │    │     │    │     │   │                        │
│  │ ───┘     └────┘     └────┘     └── │                        │
│  │                                     │                        │
│  │          ↕ Dead Time (2µs)          │                        │
│  │                                     │                        │
│  │ ────┐     ┌────┐     ┌────┐     ┌─ │                        │
│  │ Q3  │     │    │     │    │     │  │                        │
│  │     └─────┘    └─────┘    └─────┘  │                        │
│  └─────────────────────────────────────┘                        │
│                                                                  │
│  CRÍTICO: Nunca Q1 y Q3 simultáneos                             │
│           Nunca Q2 y Q4 simultáneos                             │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  INDICADORES DE ESTADO                                           │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  LED (Pin 13):                                                   │
│    • Apagado → Sistema off                                      │
│    • Encendido fijo → Funcionamiento normal                     │
│    • Parpadeo rápido (100ms) → SOBRECARGA                       │
│                                                                  │
│  Serial Monitor (115200 baud):                                   │
│    • Estado actual (ON/OFF)                                     │
│    • Voltaje de entrada (V)                                     │
│    • Corriente (valor ADC)                                      │
│    • Alertas de protección                                      │
│    • Actualización cada 1 segundo                               │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

---

## 📈 TABLA DE VALORES Y CONFIGURACIÓN

```
╔══════════════════════════════════════════════════════════════════╗
║                   PARÁMETROS DEL SISTEMA                         ║
╚══════════════════════════════════════════════════════════════════╝

┌────────────────────────────────────────────────────────────────┐
│  CONFIGURACIÓN DE SOFTWARE                                     │
├─────────────────────────┬──────────────────────────────────────┤
│ Parámetro               │ Valor                                │
├─────────────────────────┼──────────────────────────────────────┤
│ FRECUENCIA_SALIDA       │ 60 Hz (50 Hz para Europa)           │
│ FRECUENCIA_PWM          │ 20,000 Hz (20 kHz)                  │
│ TIEMPO_MUERTO_US        │ 2 microsegundos                     │
│ MUESTRAS_SENO           │ 100 (resolución tabla)              │
│ VOLTAJE_MIN             │ 22.0 V                              │
│ VOLTAJE_MAX             │ 29.0 V                              │
│ CORRIENTE_MAX           │ 800 (valor ADC)                     │
└─────────────────────────┴──────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│  ASIGNACIÓN DE PINES                                           │
├─────────────────────────┬──────────────────────────────────────┤
│ Pin Arduino             │ Función                              │
├─────────────────────────┼──────────────────────────────────────┤
│ D9 (Timer1 OC1A)        │ PWM_HIGH_A (H-Bridge alto A)        │
│ D10 (Timer1 OC1B)       │ PWM_HIGH_B (H-Bridge alto B)        │
│ D5                      │ PWM_LOW_A (H-Bridge bajo A)         │
│ D6                      │ PWM_LOW_B (H-Bridge bajo B)         │
│ A0                      │ Sensor de corriente (ACS712)        │
│ A1                      │ Sensor de voltaje (divisor)         │
│ D2 (INT0)               │ Botón ON/OFF (interrupción)         │
│ D13                     │ LED indicador de estado             │
└─────────────────────────┴──────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│  COMPONENTES EXTERNOS REQUERIDOS                               │
├─────────────────────────┬──────────────────────────────────────┤
│ Componente              │ Especificación                       │
├─────────────────────────┼──────────────────────────────────────┤
│ MOSFETs                 │ 4× IRFZ44N o IRF3205                │
│                         │ Vds > 60V, Id > 30A, Rds < 0.03Ω   │
├─────────────────────────┼──────────────────────────────────────┤
│ Drivers                 │ 4× IR2110 o IR2184                  │
│                         │ Con bootstrap (10µF + diodo rápido) │
├─────────────────────────┼──────────────────────────────────────┤
│ Transformador           │ Núcleo ferrita ETD/EE               │
│                         │ Material: N87, N97                   │
│                         │ Frecuencia: 20 kHz                   │
│                         │ Relación: 1:6 o 1:7                  │
│                         │ Primario: 10-15 vueltas             │
│                         │ Secundario: 60-90 vueltas           │
├─────────────────────────┼──────────────────────────────────────┤
│ Filtro LC               │ Inductor: 10 mH, >5A                │
│                         │ Capacitor: 10 µF, 250VAC            │
├─────────────────────────┼──────────────────────────────────────┤
│ Sensor Corriente        │ ACS712 (30A) o similar              │
├─────────────────────────┼──────────────────────────────────────┤
│ Sensor Voltaje          │ Divisor resistivo R1/R2             │
│                         │ R1=100kΩ, R2=15kΩ (ejemplo)         │
├─────────────────────────┼──────────────────────────────────────┤
│ Protección              │ Fusible 30A en entrada 24V          │
│                         │ Disipadores térmicos para MOSFETs   │
│                         │ Ventilación forzada (opcional)      │
└─────────────────────────┴──────────────────────────────────────┘
```

---

## 🌊 GENERACIÓN DE ONDA SINUSOIDAL (SPWM)

```
╔══════════════════════════════════════════════════════════════════╗
║         PRINCIPIO DE MODULACIÓN SPWM                             ║
╚══════════════════════════════════════════════════════════════════╝

┌──────────────────────────────────────────────────────────────────┐
│  TABLA DE SENO PRECALCULADA (100 muestras, 10 bits)             │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Valores de 0 a 1023 (resolución de 10 bits del Timer1)         │
│  Almacenada en PROGMEM para ahorrar RAM                          │
│                                                                  │
│  Fórmula: valor[i] = 512 + 510 × sin(2π × i / 100)             │
│                                                                  │
│  Índice:  0   10   20   30   40   50   60   70   80   90   99   │
│  Valor:  512  819 1062 1215 1221 1099  791  476  149    3    0  │
│                                                                  │
│  ┌────────────────────────────────────────────────────┐         │
│  │ Distribución de Valores (Onda Seno)                │         │
│  │                                                     │         │
│  │ 1023 ────────────────┐           ┌────────         │         │
│  │                      │           │                 │         │
│  │  819 ────────┐       │       ┌───┘                 │         │
│  │              │       │       │                     │         │
│  │  512 ────────┴───────┴───────┴─────────────────    │         │
│  │                                                     │         │
│  │  205         ┌───┐                         ┌───    │         │
│  │              │   │                         │       │         │
│  │    0 ────────┘   └─────────────────────────┘       │         │
│  │                                                     │         │
│  │  Muestras: 0    25    50    75    100             │         │
│  └────────────────────────────────────────────────────┘         │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  CONTROL DE H-BRIDGE SEGÚN POLARIDAD                             │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  SEMICICLO POSITIVO (índice 0-49):                              │
│    • OCR1A = tablaSeno[índice]    → PWM en Q1                   │
│    • OCR1B = 0                     → Q2 apagado                 │
│    • PWM_LOW_B = HIGH              → Q4 encendido               │
│    • PWM_LOW_A = LOW               → Q3 apagado                 │
│                                                                  │
│    Resultado: Corriente fluye de Q1 → Primario → Q4             │
│                                                                  │
│  SEMICICLO NEGATIVO (índice 50-99):                             │
│    • OCR1A = 0                     → Q1 apagado                 │
│    • OCR1B = tablaSeno[índice]    → PWM en Q2                   │
│    • PWM_LOW_A = HIGH              → Q3 encendido               │
│    • PWM_LOW_B = LOW               → Q4 apagado                 │
│                                                                  │
│    Resultado: Corriente fluye de Q2 → Primario → Q3             │
│                                                                  │
│  ┌────────────────────────────────────────────────────┐         │
│  │          Topología H-Bridge                        │         │
│  │                                                     │         │
│  │           Q1 ──────┬────── Q2                      │         │
│  │         (HIGH_A)   │    (HIGH_B)                   │         │
│  │                    │                               │         │
│  │                 ┌──┴──┐                            │         │
│  │            24V  │TRANS│  GND                       │         │
│  │                 └──┬──┘                            │         │
│  │                    │                               │         │
│  │           Q3 ──────┴────── Q4                      │         │
│  │         (LOW_A)         (LOW_B)                    │         │
│  │                                                     │         │
│  └────────────────────────────────────────────────────┘         │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

---

## 🔧 FUNCIONES PRINCIPALES DEL CÓDIGO

```
╔══════════════════════════════════════════════════════════════════╗
║                    MÓDULOS DE SOFTWARE                           ║
╚══════════════════════════════════════════════════════════════════╝

┌──────────────────────────────────────────────────────────────────┐
│  setup()                                                         │
├──────────────────────────────────────────────────────────────────┤
│  • Inicializar Serial (115200 baud)                             │
│  • Configurar pines I/O                                          │
│  • Apagar todos los MOSFETs                                      │
│  • Llamar configurarPWM()                                        │
│  • Llamar configurarTimerSeno()                                  │
│  • Configurar interrupción del botón (INT0)                      │
│  • Indicar inicio con parpadeos LED                              │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  configurarPWM()                                                 │
├──────────────────────────────────────────────────────────────────┤
│  • Configurar Timer1 en modo Fast PWM                            │
│  • Establecer ICR1 = 799 (TOP para 20kHz)                       │
│  • Configurar salidas OC1A (Pin 9) y OC1B (Pin 10)              │
│  • Prescaler = 1 (sin división)                                  │
│  • Inicializar OCR1A y OCR1B en 0                               │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  configurarTimerSeno()                                           │
├──────────────────────────────────────────────────────────────────┤
│  • Configurar Timer2 en modo CTC                                 │
│  • Prescaler = 64                                                │
│  • OCR2A = 41 (para 6000Hz de interrupción)                     │
│  • Habilitar interrupción TIMER2_COMPA                           │
│  • Frecuencia resultante: 60Hz × 100 muestras                    │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  ISR(TIMER2_COMPA_vect) - CRÍTICA                               │
├──────────────────────────────────────────────────────────────────┤
│  • Se ejecuta cada 166.67µs (6000Hz)                            │
│  • Verificar si inversor está encendido                          │
│  • Leer valor de tablaSeno[indiceTabla] de PROGMEM             │
│  • Determinar polaridad (positivo: 0-49, negativo: 50-99)       │
│  • Actualizar OCR1A/OCR1B y pines LOW                           │
│  • Incrementar indiceTabla (circular: 0-99)                     │
│  • TIEMPO DE EJECUCIÓN: < 10µs (crítico)                        │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  toggleInversor() - Interrupción Externa                         │
├──────────────────────────────────────────────────────────────────┤
│  • Debounce de 200ms                                             │
│  • Alternar estado: inversorEncendido = !inversorEncendido      │
│  • Si OFF: apagar todos los PWM                                  │
│  • Imprimir estado por Serial                                    │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  monitorearSistema()                                             │
├──────────────────────────────────────────────────────────────────┤
│  • Leer sensor de voltaje (A1) con divisor resistivo            │
│  • Leer sensor de corriente (A0) tipo ACS712                     │
│  • Verificar límites: voltajeMin, voltajeMax, corrienteMax      │
│  • Si fuera de límites: activar sobrecarga y apagar             │
│  • Controlar LED indicador según estado                          │
│  • LED parpadeo rápido si sobrecarga                             │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  apagarInversor()                                                │
├──────────────────────────────────────────────────────────────────┤
│  • OCR1A = 0                                                     │
│  • OCR1B = 0                                                     │
│  • digitalWrite(PWM_LOW_A, LOW)                                  │
│  • digitalWrite(PWM_LOW_B, LOW)                                  │
│  • Imprimir mensaje de protección                                │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  mostrarInformacion()                                            │
├──────────────────────────────────────────────────────────────────┤
│  • Se ejecuta cada 1000ms                                        │
│  • Mostrar estado ON/OFF                                         │
│  • Mostrar voltaje de entrada en V                               │
│  • Mostrar corriente en valor ADC                                │
│  • Indicar si hay sobrecarga activa                              │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  loop() - Bucle Principal                                        │
├──────────────────────────────────────────────────────────────────┤
│  • Llamar monitorearSistema()                                    │
│  • Llamar mostrarInformacion()                                   │
│  • delay(10ms)                                                   │
│  • Tiempo de ciclo: ~10-15ms (no crítico)                        │
└──────────────────────────────────────────────────────────────────┘
```

---

## ⚡ FUNCIONAMIENTO DEL SISTEMA

```
╔══════════════════════════════════════════════════════════════════╗
║              SECUENCIA DE OPERACIÓN COMPLETA                     ║
╚══════════════════════════════════════════════════════════════════╝

1. INICIALIZACIÓN
   ├─ Arduino arranca
   ├─ Configuración de Timers (PWM 20kHz + Seno 6kHz)
   ├─ Todos los MOSFETs apagados
   ├─ Sistema en espera (LED apagado)
   └─ Monitor serial activo (115200 baud)

2. USUARIO PRESIONA BOTÓN
   ├─ Interrupción externa (INT0) activada
   ├─ Debounce de 200ms
   ├─ inversorEncendido = true
   └─ LED encendido fijo

3. GENERACIÓN DE SPWM (Automática)
   ├─ Timer2 interrumpe cada 166.67µs
   ├─ Lee valor de tablaSeno[0..99]
   ├─ Determina polaridad (positivo/negativo)
   ├─ Actualiza PWM Timer1 (20kHz)
   │   ├─ Semiciclo +: Q1 PWM, Q4 ON
   │   └─ Semiciclo -: Q2 PWM, Q3 ON
   └─ Ciclo continuo (60Hz resultante)

4. H-BRIDGE CONMUTA
   ├─ MOSFETs conmutan a 20kHz
   ├─ Duty cycle varía según seno
   ├─ Tiempo muerto: 2µs entre transiciones
   └─ Salida: PWM modulado senoidal

5. TRANSFORMADOR ELEVA VOLTAJE
   ├─ Primario: señal PWM 24V @ 20kHz
   ├─ Núcleo de ferrita transfiere energía
   ├─ Relación 1:6 o 1:7
   └─ Secundario: ~170V pico @ 20kHz

6. FILTRO LC ELIMINA PORTADORA
   ├─ Inductor (10mH) bloquea 20kHz
   ├─ Capacitor (10µF) filtra armónicos
   ├─ Pasa frecuencia base: 60Hz
   └─ Salida: Onda sinusoidal limpia

7. RESULTADO FINAL
   ├─ 120V AC RMS
   ├─ Frecuencia: 60Hz
   ├─ Forma: Sinusoidal pura
   ├─ THD: < 5% (con filtro adecuado)
   └─ Apta para cargas sensibles

8. MONITOREO CONTINUO
   ├─ Cada 10ms: verificar sensores
   ├─ Voltaje de entrada (22-29V)
   ├─ Corriente máxima
   ├─ Si fuera de límites → protección activa
   └─ LED parpadea → sobrecarga

9. APAGADO
   ├─ Usuario presiona botón nuevamente
   ├─ inversorEncendido = false
   ├─ ISR apaga todos los PWM
   ├─ MOSFETs en estado OFF
   └─ LED apagado
```

---

## 📐 CÁLCULOS Y TEORÍA

```
╔══════════════════════════════════════════════════════════════════╗
║                    FUNDAMENTOS TÉCNICOS                          ║
╚══════════════════════════════════════════════════════════════════╝

┌──────────────────────────────────────────────────────────────────┐
│  CÁLCULO DE FRECUENCIA PWM (Timer1)                              │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  f_PWM = f_CPU / (Prescaler × (TOP + 1))                        │
│                                                                  │
│  Donde:                                                          │
│    f_CPU = 16,000,000 Hz (cristal del Arduino)                  │
│    Prescaler = 1 (sin división)                                  │
│    TOP = ICR1 = 799                                              │
│                                                                  │
│  f_PWM = 16,000,000 / (1 × 800) = 20,000 Hz = 20 kHz           │
│                                                                  │
│  Resolución = 800 pasos (equivalente a ~10 bits)                │
│  Período PWM = 50 µs                                             │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  CÁLCULO DE FRECUENCIA DE SENO (Timer2)                          │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  f_INT = f_CPU / (Prescaler × (OCR2A + 1))                      │
│                                                                  │
│  Donde:                                                          │
│    f_CPU = 16,000,000 Hz                                        │
│    Prescaler = 64                                                │
│    OCR2A = 41                                                    │
│                                                                  │
│  f_INT = 16,000,000 / (64 × 42) = 5,952 Hz ≈ 6,000 Hz          │
│                                                                  │
│  Frecuencia de salida = f_INT / MUESTRAS_SENO                   │
│                       = 6,000 / 100 = 60 Hz                     │
│                                                                  │
│  Tiempo por muestra = 1 / 6,000 = 166.67 µs                    │
│  Período completo = 100 × 166.67 µs = 16.667 ms (60Hz)         │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  CÁLCULO DEL TRANSFORMADOR                                       │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Relación de transformación básica:                              │
│    N2/N1 = V_secundario / V_primario                            │
│    N2/N1 = 170V / 24V = 7.08                                    │
│                                                                  │
│  Considerando pérdidas (~15%):                                   │
│    Relación práctica: 1:6 o 1:7                                  │
│                                                                  │
│  Ejemplo con núcleo ETD39:                                       │
│    Primario: 12 vueltas (alambre calibre 14-16)                │
│    Secundario: 80 vueltas (alambre calibre 20-22)              │
│                                                                  │
│  Frecuencia: 20 kHz → Núcleo de ferrita tipo N87/N97           │
│  Potencia: 500-1000W → Núcleo ETD39/ETD44/ETD49                │
│                                                                  │
│  Área efectiva núcleo: Ae ≥ 1.5 cm²                            │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  DISEÑO DEL FILTRO LC                                            │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Frecuencia de corte deseada:                                    │
│    f_c = 1 / (2π √(L × C))                                      │
│                                                                  │
│  Para eliminar 20kHz y pasar 60Hz:                              │
│    f_c ≈ 500 Hz (compromiso)                                    │
│                                                                  │
│  Con L = 10 mH y C = 10 µF:                                     │
│    f_c = 1 / (2π √(0.01 × 0.00001))                            │
│    f_c = 1 / (2π × 0.000316) = 503 Hz                          │
│                                                                  │
│  Atenuación a 20kHz:                                             │
│    A = -40 dB/década × log(20000/503)                           │
│    A ≈ -64 dB (excelente filtrado)                              │
│                                                                  │
│  Factor Q:                                                       │
│    Q = √(L/C) / R_carga                                         │
│    Para R_carga = 100Ω: Q ≈ 3.16                                │
│    (Puede necesitar resistor de amortiguamiento)                │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  EFICIENCIA Y PÉRDIDAS                                           │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Pérdidas principales:                                           │
│    1. MOSFETs (conmutación + conducción): ~5-8%                 │
│    2. Transformador (núcleo + cobre): ~10-15%                   │
│    3. Filtro LC (resistencia serie): ~2-3%                      │
│    4. Drivers y control: ~2%                                     │
│                                                                  │
│  Eficiencia estimada: 72-80%                                     │
│                                                                  │
│  Para 500W salida:                                               │
│    Entrada: ~625-695W                                            │
│    Corriente @ 24V: ~26-29A                                      │
│    Pérdidas: ~125-195W (disipación de calor)                    │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

---

## ⚠️ ADVERTENCIAS Y CONSIDERACIONES DE SEGURIDAD

```
╔══════════════════════════════════════════════════════════════════╗
║                    SEGURIDAD CRÍTICA                             ║
╚══════════════════════════════════════════════════════════════════╝

⚠️  PELIGRO: Este inversor genera 120V AC que puede ser LETAL

┌──────────────────────────────────────────────────────────────────┐
│  RIESGOS PRINCIPALES                                             │
├──────────────────────────────────────────────────────────────────┤
│  1. ELECTROCUCIÓN                                                │
│     • 120V AC puede causar la muerte                             │
│     • Usar aislamiento adecuado en todo el circuito             │
│     • No tocar componentes con el sistema encendido              │
│                                                                  │
│  2. INCENDIO                                                     │
│     • MOSFETs pueden alcanzar >150°C                            │
│     • Usar disipadores y ventilación forzada                     │
│     • Cables de calibre adecuado (>14 AWG para 30A)            │
│                                                                  │
│  3. EXPLOSIÓN                                                    │
│     • Baterías pueden explotar si se cortocircuitan             │
│     • Usar fusible de 30A en la entrada                          │
│     • Polaridad correcta (inversión puede destruir)              │
│                                                                  │
│  4. SHOOT-THROUGH                                                │
│     • Q1 y Q3 simultáneos = CORTOCIRCUITO                       │
│     • Verificar tiempo muerto con osciloscopio                   │
│     • Empezar con tiempo muerto de 5µs y ajustar                │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  PROCEDIMIENTO DE PRUEBA SEGURO                                  │
├──────────────────────────────────────────────────────────────────┤
│  1. Verificar circuito sin alimentación                          │
│  2. Verificar aislamiento con multímetro                         │
│  3. Primera prueba: Arduino solo (sin MOSFETs)                   │
│  4. Verificar señales PWM con osciloscopio                       │
│  5. Conectar UN MOSFET, verificar conmutación                    │
│  6. Conectar H-bridge sin transformador                          │
│  7. Verificar tiempo muerto (NO shoot-through)                   │
│  8. Conectar transformador SIN carga                             │
│  9. Medir voltaje de salida (debe ser ~120V AC)                 │
│ 10. Primera carga: bombilla de 25W                               │
│ 11. Monitorear temperatura de MOSFETs                            │
│ 12. Incrementar carga gradualmente                               │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  EQUIPO DE PROTECCIÓN PERSONAL (EPP)                             │
├──────────────────────────────────────────────────────────────────┤
│  • Guantes dieléctricos (Clase 0 mínimo)                        │
│  • Gafas de seguridad                                            │
│  • Zapatos con suela aislante                                    │
│  • Trabajar en superficie no conductora                          │
│  • Tener extintor clase C cerca                                  │
│  • Nunca trabajar solo                                           │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│  MEJORAS RECOMENDADAS PARA PRODUCCIÓN                            │
├──────────────────────────────────────────────────────────────────┤
│  1. Implementar soft-start (arranque suave)                      │
│  2. Agregar protección contra cortocircuito en salida            │
│  3. Sensor de temperatura en MOSFETs (NTC o LM35)               │
│  4. Control PID para regulación de voltaje                       │
│  5. Aislamiento óptico entre Arduino y drivers                   │
│  6. Fusible térmico en transformador                             │
│  7. Relay de desconexión automática                              │
│  8. Indicadores LED de estados y fallas                          │
│  9. Buzzer de alarma para sobrecargas                            │
│ 10. Carcasa metálica con tierra física                           │
└──────────────────────────────────────────────────────────────────┘
```

---

## 📚 RESUMEN DE ARCHIVOS DEL PROYECTO

```
╔══════════════════════════════════════════════════════════════════╗
║                  ESTRUCTURA DEL REPOSITORIO                      ║
╚══════════════════════════════════════════════════════════════════╝

Arduino-inverter/
│
├── inversor_onda_pura_24v_120v.ino
│   └─ Código principal Arduino (400 líneas)
│      • Configuración de Timers
│      • Generación SPWM
│      • Sistema de protecciones
│      • Monitoreo de sensores
│      • Control de H-Bridge
│
├── inverter.kicad_sch
│   └─ Esquemático electrónico en KiCad v6+
│      • Circuito completo del inversor
│      • Conexiones de drivers
│      • Disposición de componentes
│
└── README.md
    └─ Descripción breve del proyecto
```

---

## 🎓 CONCEPTOS CLAVE

```
┌──────────────────────────────────────────────────────────────────┐
│  GLOSARIO TÉCNICO                                                │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  SPWM: Sinusoidal Pulse Width Modulation                        │
│    Técnica de modulación PWM con envolvente sinusoidal          │
│                                                                  │
│  H-Bridge: Puente completo de 4 transistores                     │
│    Permite inversión de polaridad en la carga                    │
│                                                                  │
│  Dead Time: Tiempo muerto entre conmutaciones                    │
│    Evita conducción simultánea (shoot-through)                   │
│                                                                  │
│  Bootstrap: Técnica para alimentar drivers de lado alto          │
│    Usa capacitor y diodo para generar Vgs                        │
│                                                                  │
│  THD: Total Harmonic Distortion                                  │
│    Medida de pureza de onda (menor es mejor)                    │
│                                                                  │
│  Ferrita: Material magnético para alta frecuencia                │
│    Pérdidas bajas a 20kHz vs transformador de hierro            │
│                                                                  │
└──────────────────────────────────────────────────────────────────┘
```

---

**VERSIÓN: 1.0**  
**FECHA: 2025**  
**AUTOR: Sistema de control de inversor Arduino**

---

*Esquema generado automáticamente a partir del análisis del repositorio*
*https://github.com/Tecno-Plus/Arduino-inverter*
